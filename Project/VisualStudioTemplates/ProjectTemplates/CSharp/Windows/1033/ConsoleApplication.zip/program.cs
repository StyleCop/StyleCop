﻿// -----------------------------------------------------------------------
// <copyright file="$safeitemrootname$.cs" company="$registeredorganization$">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------

namespace $safeprojectname$
{

    using System;
    using System.Collections.Generic;
    $if$ ($targetframeworkversion$ >= 3.5)using System.Linq;
$endif$    using System.Text;

    /// <summary>
    /// TODO: Update summary.
    /// </summary>
    public class Program
    {

        /// <summary>
        /// TODO: Update summary.
        /// </summary>
        /// <param name="args">An array of <see cref="T:System.String"/> containing command line parameters.</param>
        private static void Main(string[] args)
        {
        }
    }
}
