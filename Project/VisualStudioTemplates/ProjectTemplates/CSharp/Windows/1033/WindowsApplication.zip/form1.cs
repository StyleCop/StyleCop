﻿// -----------------------------------------------------------------------
// <copyright file="$safeitemrootname$.cs" company="$registeredorganization$">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------

namespace $safeprojectname$
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    $if$ ($targetframeworkversion$ >= 3.5)using System.Linq;
$endif$    using System.Text;
    using System.Windows.Forms;

    /// <summary>
    /// TODO: Update summary.
    /// </summary>
    public partial class Form1: Form
    {

        /// <summary>
        /// TODO: Update summary.
        /// </summary>
        public Form1()
        {
            InitializeComponent();
        }
    }
}
