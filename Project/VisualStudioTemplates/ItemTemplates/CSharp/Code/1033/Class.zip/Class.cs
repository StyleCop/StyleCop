﻿// -----------------------------------------------------------------------
// <copyright file="$safeitemrootname$.cs" company="$registeredorganization$">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------

namespace $rootnamespace$
{
    using System;
    using System.Collections.Generic;
    $if$ ($targetframeworkversion$ >= 3.5)using System.Linq;
$endif$    using System.Text;

    /// <summary>
    /// TODO: Update summary.
    /// </summary>
    public class $safeitemrootname$
    {
    }
}
